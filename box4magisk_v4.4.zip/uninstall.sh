#!/system/bin/sh

rm -f /data/adb/service.d/box4magisk_service.sh
